Ayat Al Qur'an Dalam Format JSON Bahasa Indonesia dari Kemenag
===========================

Menampilkan nama surat, terjemahan dalam bahasa Indonesia, jumlah ayat dan data juz dalam al-qur'an.

## Link & Arabic Preview

* [Link preview](https://iqbalsyamhad.github.io/quran/)
<hr>
<img src="https://raw.githubusercontent.com/iqbalsyamhad/iqbalsyamhad.github.io/master/quran/screenshot/quranbootstrap.png" width="600px">

## Sumber

```
https://quran.kemenag.go.id/api/v1/
```
